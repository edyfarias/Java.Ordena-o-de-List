package ted4;

public class Aluno  implements Comparable<Aluno> {
	
		
		private String Nome;
		private int Matricula;
		
		public Aluno(String Nome, int Matricula) {
			this.Matricula = Matricula;
			this.Nome = Nome;
			
			
		}
		
		public String getNome() {
			return Nome;
		}
		
		public int getMatricula() {
			return Matricula;
			
			
		}

		@Override
		public int compareTo(Aluno pAluno) {
			return (this.Nome.compareTo(pAluno.getNome()));
			
		}
}
