package ted4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main { 
		
		public static void main(String[] args) {
				
				
			List<String> aluno = new ArrayList<String>();
			   
				
				aluno.add("Maria Matricula:01");
				aluno.add("Glaucio Matricula:02");
				aluno.add("Ednaldo Matricula:03");
			    aluno.add("Bryan Matricula:04");
				aluno.add("Neymar Matricula: 05");
				aluno.add("Fernando Matricula: 06");
				aluno.add("Victor Matricula:07");
				aluno.add("Farias Matricula:08");
				aluno.add("Livia Matricula:09");
				aluno.add("Thalles Matricula:10");
				
				
				Collections.sort(aluno);
				
				System.out.println("alunos ordem alfabetica:");

				for(String a : aluno){
				System.out.println(a);
				
				}
				  
				   }


					     

		}

